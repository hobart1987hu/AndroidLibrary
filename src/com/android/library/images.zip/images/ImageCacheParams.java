package com.android.library.images;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;

import com.android.library.cache.ImageCache;
import com.android.library.inf.IImageConstants;

public class ImageCacheParams implements IImageConstants {

    public int            memCacheSize;
    public int            diskCacheSize;
    public CompressFormat compressFormat;
    public int            compressQuality;
    public boolean        memoryCacheEnabled;
    public boolean        diskCacheEnabled;
    public boolean        mFadeInBitmap;
    public Bitmap         mLoadingBitmap;
    public Context        mContext;
    public int               mImageWidth;
    public int               mImageHeight;

    /**
     * Create a set of image cache parameters that can be provided to
     * {@link ImageCache#getInstance(android.support.v4.app.FragmentManager, ImageCacheParams)} or
     * {@link ImageWorker#addImageCache(android.support.v4.app.FragmentManager, ImageCacheParams)}.
     * 
     * @param context A context to use.
     * @param diskCacheDirectoryName A unique subdirectory name that will be appended to the application cache
     * directory. Usually "cache" or "images" is sufficient.
     */
    public ImageCacheParams(Context context){
        this.mContext = context;
    }
}
