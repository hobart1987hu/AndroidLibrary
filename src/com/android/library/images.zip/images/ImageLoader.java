package com.android.library.images;

import com.android.library.inf.IImageLoadCallback;

import android.content.Context;
import android.util.Log;
import android.widget.ImageView;

public class ImageLoader {

    private static final String         TAG = "ImageLoader";

    private ImageLoaderConfiguration    mConfiguration;

    private volatile static ImageLoader instance;

    private ImageFetcher                mImageFetcher;

    private Context                     mContext;

    /** Returns singleton class instance */
    public static ImageLoader getInstance() {
        if (instance == null) {
            synchronized (ImageLoader.class) {
                if (instance == null) {
                    instance = new ImageLoader();
                }
            }
        }
        return instance;
    }

    protected ImageLoader(){

    }
    
    public ImageCacheParams getCacheParams(){
        return mConfiguration.mImageCacheParams;
    }

    private static final String ERROR_NOT_INIT              = "ImageLoader must be init with configuration before using";
    private static final String ERROR_INIT_CONFIG_WITH_NULL = "ImageLoader configuration can not be initialized with null";
    private static final String WARNING_RE_INIT_CONFIG      = "Try to initialize ImageLoader which had already been initialized before. "
                                                              + "To re-init ImageLoader with new configuration call ImageLoader.destroy() at first.";

    public synchronized void init(ImageLoaderConfiguration configuration) {
        if (configuration == null) {
            throw new IllegalArgumentException(ERROR_INIT_CONFIG_WITH_NULL);
        }
        mContext = configuration.getApplicationContext();

        if (null == mConfiguration) {
            this.mConfiguration = configuration;
            mImageFetcher = new ImageFetcher(mContext);
        } else {
            Log.w(TAG, WARNING_RE_INIT_CONFIG);
        }
    }

    /**
     * Returns <b>true</b> - if ImageLoader {@linkplain #init(ImageLoaderConfiguration) is initialized with
     * configuration}; <b>false</b> - otherwise
     */
    public boolean isInited() {
        return mConfiguration != null;
    }

    /**
     * Checks if ImageLoader's configuration was initialized
     * 
     * @throws IllegalStateException if configuration wasn't initialized
     */
    private void checkConfiguration() {
        if (mConfiguration == null) {
            throw new IllegalStateException(ERROR_NOT_INIT);
        }
    }

    public void displayImage(String data, ImageView imageView) {
        checkConfiguration();
        mImageFetcher.loadImage(data, imageView);
    }

    public void displayImage(String data, ImageView imageView, IImageLoadCallback callback) {
        checkConfiguration();
        mImageFetcher.loadImage(data, imageView, callback);
    }

    public void onResume() {
        if (null != mImageFetcher) {
            mImageFetcher.setExitTasksEarly(false);
        }
    }

    public void onPause() {
        mImageFetcher.setExitTasksEarly(true);
        mImageFetcher.flushCache();
    }

    public void onDestroy() {
        mImageFetcher.closeCache();
    }

    public void clearCache() {
        mImageFetcher.clearCache();
    }

    public long getCacheSize() {
        return mImageFetcher.getCacheSize();
    }

    public void setPauseWork(boolean pauseWork) {
        mImageFetcher.setPauseWork(pauseWork);
    }

    @SuppressWarnings("static-access")
    public void cancelWorkForImageView(ImageView imageView) {
        if (null != imageView) {
            mImageFetcher.cancelWork(imageView);
            imageView.setImageDrawable(null);
        }
    }
}
