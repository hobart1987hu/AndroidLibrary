package com.android.library.images;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.View;

import com.android.library.BuildConfig;
import com.android.library.inf.IImageLoadCallback;

/**
 * A simple subclass of {@link ImageWorker} that resizes images from resources given a target width and height. Useful
 * for when the input images might be too large to simply load directly into memory.
 */
public class ImageResizer extends ImageWorker {

    private static final String TAG = "ImageResizer";
    protected int               mImageWidth;
    protected int               mImageHeight;

    /**
     * Initialize providing a single target image size (used for both width and height);
     * 
     * @param context
     * @param imageWidth
     * @param imageHeight
     */
    public ImageResizer(Context context, int imageWidth, int imageHeight){
        super(context);
        setImageSize(imageWidth, imageHeight);
    }

    /**
     * Initialize providing a single target image size (used for both width and height);
     * 
     * @param context
     * @param imageSize
     */
    public ImageResizer(Context context, int imageSize){
        super(context);
        setImageSize(imageSize);
    }

    /**
     * Set the target image width and height.
     * 
     * @param width
     * @param height
     */
    public void setImageSize(int width, int height) {
        mImageWidth = width;
        mImageHeight = height;
    }

    /**
     * Set the target image width
     * 
     * @param width
     */
    public void setImageWidth(int width) {
        mImageWidth = width;
    }

    /**
     * Set the target image height.
     * 
     * @param height
     */
    public void setImageHeight(int height) {
        mImageHeight = height;
    }

    /**
     * Set the target image size (width and height will be the same).
     * 
     * @param size
     */
    public void setImageSize(int size) {
        setImageSize(size, size);
    }

//    @Override
//    public Bitmap processBitmap(Object data) {
//        return processBitmap(Integer.parseInt(String.valueOf(data)));
//    }

    /**
     * The main processing method. This happens in a background task. In this case we are just sampling down the bitmap
     * and returning it from a resource.
     * 
     * @param resId
     * @return
     */
    private Bitmap processBitmap(int resId) {
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "processBitmap - " + resId);
        }
        return ImageTools.decodeSampledBitmapFromResource(mResources, resId, mImageWidth, mImageHeight, getImageCache());
    }

    @Override
    public Bitmap processBitmap(Object data, View view, IImageLoadCallback callback) {
        // TODO Auto-generated method stub
        return null;
    }
}
