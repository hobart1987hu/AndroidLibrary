package com.android.library.images;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.CompressFormat;

import com.android.library.inf.IImageConstants;

public final class ImageLoaderConfiguration implements IImageConstants {

    public   ImageCacheParams mImageCacheParams;
    
    private static Context mContext;
    
    public Context getApplicationContext(){
        return mContext;
    }
    
    public ImageLoaderConfiguration(Builder builder){
        mContext=builder.mContext;
        mImageCacheParams=new ImageCacheParams(mContext);
        this.mImageCacheParams.memCacheSize = builder.memCacheSize;
        this.mImageCacheParams.diskCacheSize = builder.diskCacheSize;
        this.mImageCacheParams.compressFormat = builder.compressFormat;
        this.mImageCacheParams.compressQuality = builder.compressQuality;
        this.mImageCacheParams.memoryCacheEnabled = builder.memoryCacheEnabled;
        this.mImageCacheParams.diskCacheEnabled = builder.diskCacheEnabled;
        this.mImageCacheParams.mContext = builder.mContext;
        this.mImageCacheParams.mFadeInBitmap = builder.mFadeInBitmap;
        this.mImageCacheParams.mLoadingBitmap = builder.mLoadingBitmap;
        this.mImageCacheParams.mImageWidth = builder.mImageWidth;
        this.mImageCacheParams.mImageHeight = builder.mImageHeight;
    }

    public static ImageLoaderConfiguration createDefault(Context context) {
        mContext=context;
        return new Builder(context).build();
    }

    public static class Builder {

        public int            memCacheSize          = DEFAULT_MEM_CACHE_SIZE;
        public int            diskCacheSize         = DEFAULT_DISK_CACHE_SIZE;
        public CompressFormat compressFormat        = DEFAULT_COMPRESS_FORMAT;
        public int            compressQuality       = DEFAULT_COMPRESS_QUALITY;
        public boolean        memoryCacheEnabled    = DEFAULT_MEM_CACHE_ENABLED;
        public boolean        diskCacheEnabled      = DEFAULT_DISK_CACHE_ENABLED;
        public boolean        mFadeInBitmap         = FADEIN_BITMAP;
        public Bitmap         mLoadingBitmap;
        public Context        mContext;
        public int            mImageWidth;
        public int            mImageHeight;

        public Builder(Context context){
            mContext = context.getApplicationContext();
          //  mImageCacheParams=new ImageCacheParams(mContext);
        }

        /**
         * Sets the memory cache size based on a percentage of the max available VM memory. Eg. setting percent to 0.2
         * would set the memory cache to one fifth of the available memory. Throws {@link IllegalArgumentException} if
         * percent is < 0.01 or > .8. memCacheSize is stored in kilobytes instead of bytes as this will eventually be
         * passed to construct a LruCache which takes an int in its constructor. This value should be chosen carefully
         * based on a number of factors Refer to the corresponding Android Training class for more discussion:
         * http://developer.android.com/training/displaying-bitmaps/
         * 
         * @param percent Percent of available app memory to use to size memory cache
         */
        public Builder setMemCacheSizePercent(float percent) {
            if (percent < 0.01f || percent > 0.8f) {
                throw new IllegalArgumentException("setMemCacheSizePercent - percent must be "
                                                   + "between 0.01 and 0.8 (inclusive)");
            }
            memCacheSize = Math.round(percent * Runtime.getRuntime().maxMemory() / 1024);
          //  mImageCacheParams.memCacheSize=memCacheSize;
            return this;
        }

        public Builder setDiskCacheSize(float size) {
            if (size <= 1f || size >= 50f) {
                throw new IllegalArgumentException("setDiskCacheSize - size must be " + "between 1 and 50 MB ");
            }
            diskCacheSize = (int)size;
         //   mImageCacheParams.diskCacheSize=diskCacheSize;
            return this;
        }

        public Builder setMemoryCacheEnabled(boolean enabled) {
            memoryCacheEnabled = enabled;
         //   mImageCacheParams.memoryCacheEnabled=enabled;
            return this;
        }

        public Builder setDiskCacheEnabled(boolean enabled) {
            diskCacheEnabled = enabled;
          //  mImageCacheParams.diskCacheEnabled=enabled;
            return this;
        }

        public Builder setCompressFormat(CompressFormat format) {
            compressFormat = format;
        //    mImageCacheParams.compressFormat=format;
            return this;
        }

        public Builder setCompressQuality(float quality) {
            if (quality < 40.0f || quality > 100f) {
                throw new IllegalArgumentException("setCompressQuality - quality must be " + "between 40 and 100");
            }
            compressQuality = (int)quality;
        //    mImageCacheParams.compressQuality=(int)quality;
            return this;
        }

        /**
         * If set to true, the image will fade-in once it has been loaded by the background thread.
         */
        public Builder setImageFadeIn(boolean fadeIn) {
            mFadeInBitmap = fadeIn;
        //    mImageCacheParams.mFadeInBitmap=fadeIn;
            return this;
        }

        /**
         * Set placeholder bitmap that shows when the the background thread is running.
         * 
         * @param bitmap
         */
        public Builder setLoadingImage(Bitmap bitmap) {
            mLoadingBitmap = bitmap;
         //   mImageCacheParams.mLoadingBitmap=bitmap;
            return this;
        }

        /**
         * Set placeholder bitmap that shows when the the background thread is running.
         * 
         * @param resId
         */
        public Builder setLoadingImage(int resId) {
            mLoadingBitmap = BitmapFactory.decodeResource(mContext.getResources(), resId);
         //   mImageCacheParams.mLoadingBitmap=mLoadingBitmap;
            return this;
        }

        public Builder setImageWidth(int targetWidth) {
            mImageWidth = targetWidth;
           // mImageCacheParams.mImageWidth=targetWidth;
            return this;
        }

        public Builder setImageHeight(int targetHeight) {
            mImageHeight = targetHeight;
            //mImageCacheParams.mImageHeight=targetHeight;
            return this;
        }

        public ImageLoaderConfiguration build() {
            return new ImageLoaderConfiguration(this);
        }
    }
}
