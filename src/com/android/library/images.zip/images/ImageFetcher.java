package com.android.library.images;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.util.Log;
import android.view.View;

import com.android.library.BuildConfig;
import com.android.library.cache.DiskLruCache;
import com.android.library.cache.ImageCache;
import com.android.library.inf.IImageConstants;
import com.android.library.inf.IImageLoadCallback;

/**
 * fetched from a URL.
 */
public class ImageFetcher extends ImageWorker implements IImageConstants {

    private static final String TAG = "ImageFetcher";

    public ImageFetcher(Context context){
        super(context);
    }

    /**
     * The main process method, which will be called by the ImageWorker in the AsyncTask background thread.
     * 
     * @param data The data to load the bitmap, in this case, a regular http URL
     * @return The downloaded and resized bitmap
     */
    private Bitmap processBitmap(String data, View view, IImageLoadCallback callback) {
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "processBitmap - " + data);
        }

        final String key = ImageCache.hashKeyForDisk(data);
        FileDescriptor fileDescriptor = null;
        FileInputStream fileInputStream = null;
        DiskLruCache.Snapshot snapshot;
        final DiskLruCache mHttpDiskCache = getImageCache().getHttpDiskCache();
        if (mHttpDiskCache != null) {
            try {
                snapshot = mHttpDiskCache.get(key);
                if (snapshot == null) {
                    if (BuildConfig.DEBUG) {
                        Log.d(TAG, "processBitmap, not found in http cache, downloading...");
                    }
                    DiskLruCache.Editor editor = mHttpDiskCache.edit(key);
                    if (editor != null) {
                        if (null == callback) {
                            if (downloadUrlToStream(data, editor.newOutputStream(DISK_CACHE_INDEX))) {
                                editor.commit();
                            } else {
                                editor.abort();
                            }
                        } else {
                            if (downloadUrlToStream(data, callback, editor.newOutputStream(DISK_CACHE_INDEX))) {
                                editor.commit();
                            } else {
                                editor.abort();
                            }
                        }
                    }
                    snapshot = mHttpDiskCache.get(key);
                }
                if (snapshot != null) {
                    fileInputStream = (FileInputStream)snapshot.getInputStream(DISK_CACHE_INDEX);
                    fileDescriptor = fileInputStream.getFD();
                }
            } catch (IOException e) {
                Log.e(TAG, "processBitmap - " + e);
            } catch (IllegalStateException e) {
                Log.e(TAG, "processBitmap - " + e);
            } finally {
                if (fileDescriptor == null && fileInputStream != null) {
                    try {
                        fileInputStream.close();
                    } catch (IOException e) {
                    }
                }
            }
        }

        Bitmap bitmap = null;

        final int targetW = getCacheParams().mImageWidth;
        final int targetH = getCacheParams().mImageHeight;

        if (targetW <= 0 || targetH <= 0) {
            throw new IllegalArgumentException("the target imageView width or target imageView height must be > 0 ....");
        }

        if (fileDescriptor != null) {
            bitmap = ImageTools.decodeSampledBitmapFromDescriptor(fileDescriptor, targetW, targetH, getImageCache());
        }
        if (fileInputStream != null) {
            try {
                fileInputStream.close();
            } catch (IOException e) {
            }
        }
        return bitmap;
    }

    @Override
    public Bitmap processBitmap(Object data, View view, IImageLoadCallback callback) {
        return processBitmap(String.valueOf(data), view, callback);
    }

    /**
     * Download a bitmap from a URL and write the content to an output stream.
     * 
     * @param urlString The URL to fetch
     * @return true if successful, false otherwise
     */
    public boolean downloadUrlToStream(String urlString, OutputStream outputStream) {
        disableConnectionReuseIfNecessary();
        HttpURLConnection urlConnection = null;
        BufferedOutputStream out = null;
        BufferedInputStream in = null;

        try {
            final URL url = new URL(urlString);
            urlConnection = (HttpURLConnection)url.openConnection();
            in = new BufferedInputStream(urlConnection.getInputStream(), IO_BUFFER_SIZE);
            out = new BufferedOutputStream(outputStream, IO_BUFFER_SIZE);
            int b;
            while ((b = in.read()) != -1) {
                out.write(b);
            }
            return true;
        } catch (final IOException e) {
            Log.e(TAG, "Error in downloadBitmap - " + e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (final IOException e) {
            }
        }
        return false;
    }

    /**
     * Download a bitmap from a URL and write the content to an output stream.
     * 
     * @param urlString The URL to fetch
     * @return true if successful, false otherwise
     */
    public boolean downloadUrlToStream(String urlString, IImageLoadCallback callback, OutputStream outputStream) {
        disableConnectionReuseIfNecessary();
        HttpURLConnection urlConnection = null;
        BufferedOutputStream out = null;
        BufferedInputStream in = null;

        try {
            final URL url = new URL(urlString);
            urlConnection = (HttpURLConnection)url.openConnection();
            in = new BufferedInputStream(urlConnection.getInputStream(), IO_BUFFER_SIZE);
            out = new BufferedOutputStream(outputStream, IO_BUFFER_SIZE);
            final int contentSize = urlConnection.getContentLength();
            int total_length = 0;
            int b;
            while ((b = in.read()) != -1) {
                total_length += b;
                callback.publishProgress(contentSize, (int)((total_length / (float)contentSize) * 100));
                out.write(b);
            }
            return true;
        } catch (final IOException e) {
            Log.e(TAG, "Error in downloadBitmap - " + e);
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (final IOException e) {
            }
        }
        return false;
    }

    /**
     * Workaround for bug pre-Froyo, see here for more info:
     * http://android-developers.blogspot.com/2011/09/androids-http-clients.html
     */
    public static void disableConnectionReuseIfNecessary() {
        // HTTP connection reuse which was buggy pre-froyo
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.FROYO) {
            System.setProperty("http.keepAlive", "false");
        }
    }
}
